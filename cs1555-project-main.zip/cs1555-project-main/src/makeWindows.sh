javac -cp "postgresql-42.2.18.jar;." driver.java
java -cp "postgresql-42.2.18.jar;." driver
