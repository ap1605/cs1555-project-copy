javac -cp ./postgresql.jar driver.java
java -cp .:./postgresql.jar driver
